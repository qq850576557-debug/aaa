#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
python3 deploy/apk-download/publish.py --apk app.apk --release update.json --logo public/brand/source/chunmo-original-circle.png "$@"
