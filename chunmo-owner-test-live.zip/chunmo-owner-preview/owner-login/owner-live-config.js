module.exports = {"origin": "https://owner-test.chmsj.cn", "appId": "wxb48a7abb3858a252", "deployment": "test"};
