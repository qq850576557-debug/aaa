App({
  privacyResolvers: [],
  onLaunch() {
    wx.onNeedPrivacyAuthorization?.((resolve) => {
      const pages = getCurrentPages();
      const page = pages[pages.length - 1];
      if (page?.route !== 'owner-login/pages/profile/index') {
        resolve({ event: 'disagree' });
        return;
      }
      this.privacyResolvers.push(resolve);
      page.setData({ privacyVisible: true });
    });
  },
  resolvePrivacy(agree) {
    this.privacyResolvers.splice(0).forEach((resolve) => resolve(
      agree ? { event: 'agree', buttonId: 'chunmo-privacy-agree' } : { event: 'disagree' },
    ));
    const pages = getCurrentPages();
    const page = pages[pages.length - 1];
    if (page?.route === 'owner-login/pages/profile/index') page.setData({ privacyVisible: false });
  },
});
